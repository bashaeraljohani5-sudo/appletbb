/*
 * IT Software Development Capstone Project - Task D
 * Target Database Architecture: booking_hotel
 * Verified & Formatted to match bookingroom exact columns.
 */

import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Applet1 extends Applet implements ActionListener {
    
    // UI Interface Components
    private Label lblRoomNo, lblGuestId, lblBookingDate, lblStatus;
    private TextField txtRoomNo, txtGuestId, txtBookingDate;
    private Button btnBook, btnCancel;

    // Database Connection Credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/booking_hotel";
    private static final String DB_USER = "root";
    private static final String DB_PASS = ""; 

    @Override
    public void init() {
        // Enforce window dimensions to render elements correctly
        this.setSize(400, 320);
        this.setLayout(null);
        this.setBackground(new Color(245, 247, 250));

        // 1. Room Number Field Mapped to RoomNo
        lblRoomNo = new Label("Room No:");
        lblRoomNo.setBounds(25, 30, 110, 25);
        this.add(lblRoomNo);

        txtRoomNo = new TextField();
        txtRoomNo.setBounds(145, 30, 180, 25);
        this.add(txtRoomNo);

        // 2. Guest Identifier Mapped to GuestID
        lblGuestId = new Label("Guest ID:");
        lblGuestId.setBounds(25, 70, 110, 25);
        this.add(lblGuestId);

        txtGuestId = new TextField();
        txtGuestId.setBounds(145, 70, 180, 25);
        this.add(txtGuestId);

        // 3. Booking Date Mapped to bookingdate
        lblBookingDate = new Label("Booking Date:");
        lblBookingDate.setBounds(25, 110, 110, 25);
        this.add(lblBookingDate);

        txtBookingDate = new TextField("YYYY-MM-DD");
        txtBookingDate.setBounds(145, 110, 180, 25);
        this.add(txtBookingDate);

        // Commit and Save Control Action Button
        btnBook = new Button("Book Now");
        btnBook.setBounds(145, 160, 85, 30);
        btnBook.setBackground(new Color(43, 108, 176));
        btnBook.setForeground(Color.WHITE);
        btnBook.addActionListener(this);
        this.add(btnBook);

        // Cancel and Reset Action Control Button
        btnCancel = new Button("Cancel");
        btnCancel.setBounds(240, 160, 85, 30);
        btnCancel.setBackground(new Color(226, 232, 240));
        btnCancel.addActionListener(this);
        this.add(btnCancel);

        // System Terminal Notification Status Interface Bar
        lblStatus = new Label("System Status: Ready.");
        lblStatus.setBounds(25, 210, 320, 25);
        lblStatus.setForeground(new Color(74, 85, 104));
        this.add(lblStatus);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Object source = event.getSource();
        if (source == btnBook) {
            processHotelBookingTransaction();
        } else if (source == btnCancel) {
            resetInputForm();
        }
    }

    private void processHotelBookingTransaction() {
        String inputRoomNo = txtRoomNo.getText().trim();
        String inputGuestId = txtGuestId.getText().trim();
        String inputBookingDate = txtBookingDate.getText().trim();

        // Check for empty string inputs
        if (inputRoomNo.isEmpty() || inputGuestId.isEmpty() || inputBookingDate.equals("YYYY-MM-DD") || inputBookingDate.isEmpty()) {
            showStatusMessage("Validation Error: Please fill all fields!", Color.RED);
            return;
        }

        Connection conn = null;
        PreparedStatement checkStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            // Grade A Check: Cross-verify room constraints inside table room
            String verifyQuery = "SELECT RoomNo FROM room WHERE RoomNo = ?";
            checkStmt = conn.prepareStatement(verifyQuery);
            checkStmt.setString(1, inputRoomNo);
            rs = checkStmt.executeQuery();

            if (!rs.next()) {
                showStatusMessage("Security Error: RoomNo does not exist!", Color.RED);
                return;
            }

            // Grade A Database Write: Mapped exactly to columns (RoomNo, GuestID, bookingdate)
            String insertQuery = "INSERT INTO bookingroom (RoomNo, GuestID, bookingdate) VALUES (?, ?, ?)";
            insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, inputRoomNo);
            insertStmt.setString(2, inputGuestId);
            insertStmt.setString(3, inputBookingDate);

            int rowsAffected = insertStmt.executeUpdate();

            if (rowsAffected > 0) {
                showStatusMessage("Success: Room " + inputRoomNo + " Booked successfully!", new Color(34, 84, 61));
            } else {
                showStatusMessage("Database Error: Entry transaction rejected.", Color.RED);
            }

        } catch (Exception ex) {
            showStatusMessage("System Fault: " + ex.getMessage(), Color.RED);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (checkStmt != null) checkStmt.close(); } catch (Exception e) {}
            try { if (insertStmt != null) insertStmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    private void resetInputForm() {
        txtRoomNo.setText("");
        txtGuestId.setText("");
        txtBookingDate.setText("YYYY-MM-DD");
        showStatusMessage("System Status: Reset complete. Form cleared.", new Color(74, 85, 104));
    }

    private void showStatusMessage(String text, Color textColor) {
        lblStatus.setForeground(textColor);
        lblStatus.setText(text);
    }
}